export const adminMenu = [
    { //hệ thống

        name: 'menu.system.header', menus: [
            { name: 'menu.system.system-administrator.user-manage', link: '/system/item-manage' },
            { name: 'menu.system.system-administrator.product-manage', link: '/system/shops-manage' },
            { name: 'menu.system.system-administrator.register-package-group-or-account', link: '/system/overview' },
            // {


            //     // subMenus: [

            //     // ],
            //     // name: 'menu.system.system-administrator.header',

            // },
            // { name: 'menu.system.system-parameter.header', link: '/system/system-parameter' },
        ]
    },
];